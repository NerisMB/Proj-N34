// Busca uma imagem de perfil para o personagem seguido.
// O Google encerrou a API oficial de imagens, então usa a Brave Search API (variável BRAVE_API_KEY).
const J = (o, s = 200) => new Response(JSON.stringify(o), { status: s, headers: { "content-type": "application/json", "cache-control": "public, max-age=86400" } });
// Acesso do GitHub Pages: pedidos de outro site só passam se a origem for permitida.
// Variável ALLOWED_ORIGINS (opcional, separada por vírgula, ex.: https://usuario.github.io). Sem ela, aceita qualquer https://*.github.io.
const _perm = (process.env.ALLOWED_ORIGINS || "").split(",").map(x => x.trim()).filter(Boolean);
const origemOk = o => !!o && (_perm.length ? _perm.includes(o) : /^https:\/\/[a-z0-9-]+\.github\.io$/i.test(o));
const corsDe = o => ({ "access-control-allow-origin": o, "access-control-allow-headers": "x-n34-proof, content-type", "access-control-allow-methods": "GET, PUT, OPTIONS", "access-control-expose-headers": "x-n34-proxy", "access-control-max-age": "86400", vary: "origin" });
async function comCors(req, trata) {
  const o = req.headers.get("origin"), cruzada = origemOk(o), cab = cruzada ? corsDe(o) : {};
  if (req.method === "OPTIONS") return new Response(null, { status: cruzada ? 204 : 403, headers: cab });
  const r = await trata(cruzada);
  for (const [k, v] of Object.entries(cab)) r.headers.set(k, v);
  return r;
}
export default req => comCors(req, cruzada => trata(req, cruzada));

async function trata(req, cruzada) {
  const sfs = req.headers.get("sec-fetch-site");
  if (sfs && sfs !== "same-origin" && !cruzada) return J({ erro: "origem não permitida" }, 403);
  const key = process.env.BRAVE_API_KEY || "";
  if (!key) return J({ erro: "busca de ícones não configurada" }, 501);
  const q = (new URL(req.url).searchParams.get("q") || "").trim().slice(0, 100);
  if (q.length < 2) return J({ erro: "busca vazia" }, 400);
  const r = await fetch("https://api.search.brave.com/res/v1/images/search?count=6&safesearch=strict&q=" + encodeURIComponent(q), { headers: { "X-Subscription-Token": key, Accept: "application/json" } });
  if (!r.ok) return J({ erro: "a busca falhou (" + r.status + ")" }, 502);
  const j = await r.json();
  const urls = (j.results || []).map(x => x && x.thumbnail && x.thumbnail.src).filter(u => typeof u === "string" && u.startsWith("https://")).slice(0, 6);
  return J({ urls });
}
