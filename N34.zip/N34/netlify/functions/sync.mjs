import { getStore } from "@netlify/blobs";
import { createHash } from "node:crypto";

// 1) Sincronização: guarda só texto cifrado (n34v1.<base64>), indexado por um hash. Não vê User ID nem API Key.
//    Para gravar, o aparelho precisa mandar uma "prova" (derivada da API key). O primeiro que grava um id fica
//    dono dele; quem não tem a prova não consegue sobrescrever.
// 2) Imagens: repassa imagens do rule34.xxx para o navegador conseguir copiá-las (sem bloqueio de CORS).
// Proteções: só aceita pedidos feitos pelo próprio site, limita tamanho e quantidade de pedidos por IP.
const hostOk = h => /(^|\.)rule34\.xxx$/.test(h);
const sha = t => createHash("sha256").update(t).digest("hex");
const MAX_BODY = 1_500_000;

async function limite(ip, nome, max) {   // contador simples por IP, por minuto
  try {
    const rl = getStore("n34-rl"), min = Math.floor(Date.now() / 60000), k = `${nome}:${ip}:${min}`;
    const n = Number((await rl.get(k)) || 0) + 1;
    if (n > max) return false;
    await rl.set(k, String(n));
    Promise.resolve(rl.delete(`${nome}:${ip}:${min - 2}`)).catch(() => {});
  } catch {}
  return true;
}
const erro = (msg, status) => new Response(msg, { status });
// Acesso do GitHub Pages: pedidos de outro site só passam se a origem for permitida.
// Variável ALLOWED_ORIGINS (opcional, separada por vírgula, ex.: https://usuario.github.io). Sem ela, aceita qualquer https://*.github.io.
const _perm = (process.env.ALLOWED_ORIGINS || "").split(",").map(x => x.trim()).filter(Boolean);
const origemOk = o => !!o && (_perm.length ? _perm.includes(o) : /^https:\/\/[a-z0-9-]+\.github\.io$/i.test(o));
const corsDe = o => ({ "access-control-allow-origin": o, "access-control-allow-headers": "x-n34-proof, content-type", "access-control-allow-methods": "GET, PUT, OPTIONS", "access-control-expose-headers": "x-n34-proxy", "access-control-max-age": "86400", vary: "origin" });
async function comCors(req, trata) {
  const o = req.headers.get("origin"), cruzada = origemOk(o), cab = cruzada ? corsDe(o) : {};
  if (req.method === "OPTIONS") return new Response(null, { status: cruzada ? 204 : 403, headers: cab });
  const r = await trata(cruzada);
  for (const [k, v] of Object.entries(cab)) r.headers.set(k, v);
  return r;
}

export default (req, context) => comCors(req, cruzada => trata(req, context, cruzada));

async function trata(req, context, cruzada) {
  const u = new URL(req.url);
  const ip = (context && context.ip) || req.headers.get("x-nf-client-connection-ip") || "?";
  const sfs = req.headers.get("sec-fetch-site");
  if (sfs && sfs !== "same-origin" && !cruzada) return erro("origem não permitida", 403);

  const img = u.searchParams.get("img");
  if (img) {
    const ref = req.headers.get("referer");
    if (ref && !cruzada) { try { if (new URL(ref).host !== u.host) return erro("origem não permitida", 403); } catch {} }
    if (!(await limite(ip, "img", 60))) return erro("muitos pedidos", 429);
    let t; try { t = new URL(img); } catch { return erro("url inválida", 400); }
    if (t.protocol !== "https:" || !hostOk(t.hostname)) return erro("host não permitido", 400);
    const r = await fetch(t, { headers: { "user-agent": "N34/1.0 (cliente pessoal)", referer: "https://rule34.xxx/" } });
    if (!r.ok) return erro("erro " + r.status, r.status);
    const ct = r.headers.get("content-type") || "";
    if (!/^(image|video)\//.test(ct)) return erro("tipo não permitido", 400);
    return new Response(r.body, { headers: { "x-n34-proxy": "1", "content-type": ct, "cache-control": "public, max-age=86400" } });
  }

  const id = u.searchParams.get("id") || "";
  if (!/^[a-f0-9]{64}$/.test(id)) return erro("id inválido", 400);
  const put = req.method === "PUT";
  if (!(await limite(ip, put ? "put" : "get", put ? 30 : 120))) return erro("muitos pedidos", 429);
  const store = getStore("n34-sync");

  if (req.method === "GET") {
    const v = await store.get(id);
    return v ? new Response(v, { headers: { "content-type": "text/plain", "cache-control": "no-store" } }) : new Response(null, { status: 204 });
  }
  if (put) {
    const proof = req.headers.get("x-n34-proof") || "";
    if (!/^[a-f0-9]{64}$/.test(proof)) return erro("prova ausente", 401);
    const dono = await store.get("p:" + id), ph = sha(proof);
    if (dono && dono !== ph) return erro("sem permissão para este id", 403);
    const body = await req.text();
    if (body.length > MAX_BODY) return erro("grande demais", 413);
    if (!/^n34v1\.[A-Za-z0-9+/=]{60,}$/.test(body)) return erro("formato inválido", 400);
    await store.set(id, body);
    if (!dono) await store.set("p:" + id, ph);
    return new Response("ok");
  }
  return erro("método não permitido", 405);
}
